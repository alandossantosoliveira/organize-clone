package com.example.alan8.organizzeclone.activity.model;

public class SaldoAnual {
    private String ano;
    private Double saldo;

    public SaldoAnual() {
    }

    public String getAno() {
        return ano;
    }

    public void setAno(String ano) {
        this.ano = ano;
    }

    public Double getSaldo() {
        return saldo;
    }

    public void setSaldo(Double saldo) {
        this.saldo = saldo;
    }
}
